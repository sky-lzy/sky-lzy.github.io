function [W, p] = DigitalBeamforming(H, P_static, P_max, SE_min, sigma_n)

    [~, K] = size(H);

    regular_factor = 0; % set regular factor 
    H_H = (H'*H + regular_factor*eye(K))^-1; 
    t = real(diag(H_H)); 
    P_min = sigma_n^2 * (2^SE_min - 1); 

    % Alternative Optimization (Dinkelbach's Method)
    threshold = 1e-6;
    lambda_last = 0;
    epochs = 100;

    for epoch = 1:epochs

        % water-filling solution (solve the value of p)
        [t_sort, ~] = sort(t);
        iter_t = 1;
        P_allocate_max = P_max - P_min*sum(t); 
        if P_allocate_max < 0
            error("Cannot reach the minimum SE!"); 
        end
        while (iter_t <= K)
            temp_level = t_sort(iter_t) * (sigma_n^2 + P_min);
            water_sum = sum(temp_level - (sigma_n^2 + P_min) .* t_sort(1:iter_t)); 
            if (water_sum > P_allocate_max)
                break; 
            end
            iter_t = iter_t + 1;
        end
        water_level = temp_level - (water_sum - P_allocate_max) / (iter_t - 1); 
        % water_level = t_sort(iter_t-1) * sigma_n^2 + (P_max - sum(t_sort(iter_t-1) * sigma_n^2 - sigma_n^2 .* t_sort(1:iter_t-1))) / iter_t; 
        water_level = min([water_level, 1/log(2)/lambda_last]);
        p = max(water_level./t - sigma_n^2, P_min); 
        
        % update lambda 
        lambda_now = sum(log2(1 + p/sigma_n^2)) / (P_static + sum(p .* t));
        
        % recycle condition 
        if (abs(lambda_now - lambda_last) < threshold)
            break;
        end
        lambda_last = lambda_now;
        
    end
    
    % fprintf('Max Power: %f, Real Power: %f\n', P_max, p'*t);
    % Zero-Forcing Precoding
    W = H * H_H * diag(sqrt(p)); 

end
