clear; close all; clc; 

c = 299792458;
fc = 3.5e9;
lambda = c/fc;
kappa = 4; 

RIS = struct(); 
BS = struct(); 
US = struct(); 
RIS.Ny = 8; 
RIS.Nz = 8; 
RIS.N = RIS.Ny * RIS.Nz; 
BS.M = 8; 
US.M = 1; 
US.K = 4; 

% Hyperparameters for the location of BS and users
R_BS_range = [200, 200];
% R_BS_range = [20, 100];
theta_BS_range = [-pi/2, pi/2];
phi_BS_range = [pi/3, pi*2/3];

R_US_range = [200, 200];
% R_US_range = [10, 200];
theta_US_range = [-pi/2, pi/2];
phi_US_range = [pi/3, pi*2/3];

% Simulation sets
PSD_noise = db2pow(-174-30);
BW = 180e3;
P_noise = PSD_noise * BW;
sigma_noise = sqrt(P_noise);
P_static = 4; 
P_RIS = 1e-3; 
SE_min = 1e-4; 
P_BS_dB = [-10, -5, 0, 5]; 
P_BS = db2pow(P_BS_dB); 

% Pre-simulation 
rng(1); 
epochs = 8; 

% Simulating 
SE = zeros(4, epochs); 
EE = zeros(4, epochs); 
[US.dis, US.theta, US.phi] = randPos(R_US_range, theta_US_range, phi_US_range, US.K); 
[BS.dis, BS.theta, BS.phi] = randPos(R_BS_range, theta_BS_range, phi_BS_range); 
[G, F] = Generate_channel(RIS, BS, US, lambda, kappa); 
% RIS_state = randi([0, 1], RIS.N, 1); 
RIS_state = zeros(RIS.N, 1); 
RIS_state = kron(RIS_state, ones(1, 4)); 

for epoch = 1:epochs 

    for k = 1:4  
        H = G' * diag(1 - 2*RIS_state(:, k)) * F; 
        [W_BS, P_allocate] = DigitalBeamforming(H, P_static + P_RIS*sum(RIS_state(:, k)), P_BS(k), SE_min, sigma_noise); 
        update_state = RISBeamforming_SDP(F, G, P_allocate, P_RIS, P_BS(k), RIS_state(:, k)); 
        % update_state = RISBeamforming_SubOpt(F, G, P_allocate, P_RIS, P_BS(k), RIS_state(:, k)); 
        RIS_state(:, k) = update_state; 
        SE(k, epoch) = sum(log2(1 + P_allocate/sigma_noise^2));
        EE(k, epoch) = BW * sum(log2(1 + P_allocate/sigma_noise^2)) / (P_static + trace(W_BS'*W_BS) + P_RIS * sum(RIS_state(:, k))); 

    end

end

figure; hold on; box on; grid on; 
plot(1:epochs, SE(4, :), 'Marker', '^', 'Linewidth', 2, 'Color', '#FF0000'); 
plot(1:epochs, SE(3, :), 'Marker', 'x', 'Linewidth', 2, 'Color', '#0000FF'); 
plot(1:epochs, SE(2, :), 'Marker', '*', 'Linewidth', 2, 'Color', '#EDB120'); 
plot(1:epochs, SE(1, :), 'Marker', 'o', 'Linewidth', 2, 'Color', '#77AC30'); 
set(legend('$P_{BS} = 5$ dB', '$P_{BS} = 0$ dB', '$P_{BS} = -5$ dB', '$P_{BS} = -10$ dB'), 'interpreter', 'latex'); 
xlabel('Number of Iterations');
ylabel('Spectrum Efficiency (bps/Hz'); 
% saveas(gcf, 'figures/SE_iter_AO_SDP.fig'); 

figure; hold on; box on; grid on; 
plot(1:epochs, EE(4, :), 'Marker', '^', 'Linewidth', 2, 'Color', '#FF0000'); 
plot(1:epochs, EE(3, :), 'Marker', 'x', 'Linewidth', 2, 'Color', '#0000FF'); 
plot(1:epochs, EE(2, :), 'Marker', '*', 'Linewidth', 2, 'Color', '#EDB120'); 
plot(1:epochs, EE(1, :), 'Marker', 'o', 'Linewidth', 2, 'Color', '#77AC30'); 
set(legend('$P_{BS} = 5$ dB', '$P_{BS} = 0$ dB', '$P_{BS} = -5$ dB', '$P_{BS} = -10$ dB'), 'interpreter', 'latex'); 
xlabel('Number of Iterations');
ylabel('Energy Efficiency (bits/Joule)');
% saveas(gcf, 'figures/EE_iter_AO_SDP.fig'); 

% Utils
function [R, theta, psi] = randPos(R_range, theta_range, psi_range, Number)

    if (~exist('Number', 'var'))
        Number = 1;
    end

    R = R_range(1) + (R_range(2) - R_range(1)) * rand(Number, 1);
    theta = theta_range(1) + (theta_range(2) - theta_range(1)) * rand(Number, 1);
    psi = psi_range(1) + (psi_range(2) - psi_range(1)) * rand(Number, 1);

end
