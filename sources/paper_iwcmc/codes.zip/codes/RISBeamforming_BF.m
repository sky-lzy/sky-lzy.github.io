function RIS_state = RISBeamforming_BF(F, G, P_allocate, P_0, P_max, last_state)

    [N, ~] = size(F);
    q_state = 1 - last_state*2; 
    ratio_iter = 1; 
    % epochs = 100; 

    % for epoch = 1:epochs
    while true
        
        H = G' * diag(q_state) * F; 
        H_H = (H'*H)^-1;
        der_q = zeros(N, 1);
        for iter_n = 1:N 
            temp_der = F(iter_n, :)' * G(iter_n, :) * H; 
            der_q(iter_n) = -0.5*P_0 - P_allocate' * real(diag(H_H * (temp_der + temp_der') * H_H)); 
        end
        P_use = P_allocate' * real(diag(H_H)); 

        [~, der_q_idx] = sort(der_q .* q_state, 'descend'); 
        flag = 0;
        for iter_ptr = 1:round(N * ratio_iter)
            % if (der_q(der_q_idx(iter_ptr)) * q_state(der_q_idx(iter_ptr)) > 0) 
            q_state(der_q_idx(iter_ptr)) = -1 * q_state(der_q_idx(iter_ptr)); 
            [feasible, P_temp] = Is_feasible(F, G, q_state, P_0, P_max, P_allocate, P_use, q_state(der_q_idx(iter_ptr))); 
            if (feasible)
                P_use = P_temp; 
                flag = true; 
            else 
                q_state(der_q_idx(iter_ptr)) = -1 * q_state(der_q_idx(iter_ptr)); 
            end
            % end
        end
                
        if (~flag)
            break;
        end
    end

    RIS_state = double(q_state < 0); 

end


function [flag, P_use] = Is_feasible(F, G, state, P_0, P_max, P_allocate, P_last, direction)

    H = G' * diag(state) * F; 
    P_use = P_allocate' * real(diag((H'*H)^-1)); 
    if ((P_use <= P_max) && (-P_0*direction + P_use - P_last < 0)) 
        flag = true;
    else
        flag = false;
    end

end
