function RIS_state = RISBeamforming_SubOpt(F, G, P_allocate, P_0, P_max, last_state)
    
    [N, ~] = size(F); 
    epsilon = 1e-4;
    is_converge = false;
    RIS_state = last_state;
    q = 1 - 2*RIS_state;
    H = G' * diag(q) * F; 
    t = diag((H'*H)^-1); 
    if P_allocate'*t > P_max*1.00001
        fprintf("Power constraint unsatisfied\n");
    end
    target_prev = -0.5*P_0*sum(q)+P_allocate'*t;
    
    while ~is_converge
        target_tmp = target_prev;
%         target_tmp
%         P_allocate'*t
        for idx = 1:N
            RIS_state(idx) = ~RIS_state(idx);
            q = 1 - 2*RIS_state;
            H = G' * diag(q) * F; 
            t = diag((H'*H)^-1);
            target_cur = -0.5*P_0*sum(q)+P_allocate'*t;
            if target_cur < target_tmp && P_allocate'*t <= P_max
                target_tmp = target_cur;
            else
                RIS_state(idx) = ~RIS_state(idx);
            end
        end
        

        if abs(target_tmp-target_prev) < epsilon
            is_converge = true;
            q = 1 - 2*RIS_state;
            H = G' * diag(q) * F; 
            t = diag((H'*H)^-1); 
            if P_allocate'*t > P_max*1.00001
                fprintf("Power constraint unsatisfied\n");
            end
            tmp_1 = (RIS_state == 0);
            tmp_2 = (RIS_state == 1);
            tmp = tmp_1 + tmp_2;
            if sum(tmp) ~= length(tmp)
                fprintf("RIS_state error\n");
            end
        else
            target_prev = target_tmp;
        end
    end
end

