function RIS_state = RISBeamforming_SDP(F, G, P_allocate, P_0, P_max, last_state) 

    [N, K] = size(F); 
    E0 = [zeros(N, N), ones(N, 1); ones(1, N), 0]; 
    G1 = [G*G', zeros(N, 1); zeros(1, N+1)]; 
    F1 = [F; zeros(1, K)]; 
    P1 = diag(P_allocate.^-1); 
    E = zeros(N+1, N+1, N+1); 
    for iter_n = 1:N+1 
        E(iter_n, iter_n, iter_n) = 1; 
    end

    % cvx_solver Mosek
    cvx_precision high
    cvx_begin sdp quiet
        variable X(N+1, N+1) semidefinite 
        minimize -0.5*P_0*trace(E0*X) + 0.5* trace_inv(F1'*(X.*G1)*F1*P1 + (F1'*(X.*G1)*F1*P1)') 
        subject to 
            0.5*trace_inv(F1'*(X.*G1)*F1*P1 + (F1'*(X.*G1)*F1*P1)') <= P_max; 
            for iter_n = 1:N+1 
                trace(E(:, :, iter_n)*X) == 1; 
            end
    cvx_end
    
    % random 
    Q = X(1:N, 1:N); 
    V = sqrtm(Q); 
    N_pro = 1e5; 
    opt_q = zeros(N, 1); 
    opt_value = Inf; 
    for iter_pro = 1:N_pro 
        u = randn(N, 1); 
        u = u / norm(u); 
        temp_q = double(V'*u > 0) * 2 - 1; 
        temp_value = cal_value(F, G, temp_q, P_0, P_allocate); 
        if (temp_value < opt_value) 
            opt_value = temp_value; 
            opt_q = temp_q; 
        end
    end

    % CSCG
    %{
    Q = X(1:N, 1:N); 
    [V, D] = eig(Q); 
    opt_q = zeros(N, 1); 
    opt_value = Inf; 
    N_pro = 1e5; 
    for iter_pro = 1:N_pro 
        r = (randn(N, 1) + 1j * randn(N, 1)) / sqrt(2); 
        temp_q = double(V*sqrtm(D)*r > 0) * 2 - 1; 
        temp_value = cal_value(F, G, temp_q, P_0, P_allocate); 
        if (temp_value < opt_value) 
            opt_value = temp_value; 
            opt_q = temp_q; 
        end
    end
    %}

    RIS_state = double(opt_q < 0); 

    if (cal_value(F, G, (1-RIS_state*2), P_0, P_allocate) > cal_value(F, G, (1-last_state*2), P_0, P_allocate)) 
        RIS_state = last_state; 
    end

end

function value = cal_value(F, G, q_state, P_0, P_allocate)
    H = G' * diag(q_state) * F; 
    value = -0.5*P_0*sum(q_state) + P_allocate' * diag((H'*H)^-1); 
end