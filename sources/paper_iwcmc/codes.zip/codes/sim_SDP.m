clear; close all; clc;

% warning('off', 'CVX:UnsymmetricLMI'); 

c = 299792458;
fc = 3.5e9;
lambda = c/fc;
kappa = 4; 


% RIS, BS and Users
RIS = struct();
RIS.Ny = 8;
RIS.Nz = 8;
RIS.N = RIS.Ny * RIS.Nz;


% Hyperparameters for the location of BS and users
R_BS_range = [200, 200];
% R_BS_range = [20, 100];
theta_BS_range = [-pi/2, pi/2];
phi_BS_range = [pi/3, pi*2/3];

R_US_range = [200, 200];
% R_US_range = [10, 200];
theta_US_range = [-pi/2, pi/2];
phi_US_range = [pi/3, pi*2/3];


% Simulation sets
PSD_noise = db2pow(-174-30);
BW = 180e3;
P_noise = PSD_noise * BW;
sigma_noise = sqrt(P_noise);
P_static = 4; 
P_RIS = 1e-3; 
SE_min = 1e-4; 
% P_min = sigma_noise^2 * (2^SE_min - 1); 


% Pre-simulation 
rng(0); 
epochs = 100; 
max_iters = 50;
iter_threshold = 1; 
P_BS_number = 10; 
P_BS_range = logspace(-1, 1, P_BS_number); 


% Simulating 
SE_BF = zeros(P_BS_number, 1);
EE_BF = zeros(P_BS_number, 1);
SE_exist = zeros(P_BS_number, 1); 
EE_exist = zeros(P_BS_number, 1); 
SE_SDP = zeros(P_BS_number, 1);
EE_SDP = zeros(P_BS_number, 1);
SE_rand = zeros(P_BS_number, 1);
EE_rand = zeros(P_BS_number, 1);
SE_close_RIS = zeros(P_BS_number, 1);
EE_close_RIS = zeros(P_BS_number, 1); 
fprintf('|Epoch/Epochs |   SDP Relaxation  |   BF Searching    |    Exist Method   |    Random RIS     |     Closed RIS    |\n'); 
fprintf('|             |   SE   |    EE    |   SE   |    EE    |   SE   |    EE    |   SE   |    EE    |   SE   |    EE    |\n');

BS = struct();
US = struct();
for epoch = 1:epochs
    BS(epoch).M = 8;
    US(epoch).M = 1;
    US(epoch).K = 4;

    [BS(epoch).dis, BS(epoch).theta, BS(epoch).phi] = randPos(R_BS_range, theta_BS_range, phi_BS_range); 
    [US(epoch).dis, US(epoch).theta, US(epoch).phi] = randPos(R_US_range, theta_US_range, phi_US_range, US(epoch).K); 
end
    
parfor k = 1:P_BS_number
    % for k = 1:1
        
    rng(0);
    for epoch = 1:epochs 
        % for epoch = 1:1 
            
        % Generate Channels
        [G, F] = Generate_channel(RIS, BS(epoch), US(epoch), lambda, kappa); 

        % EE Optimization (BF Searching)
%         RIS_state_BF = randi([0, 1], RIS.N, 1); 
        RIS_state_BF = zeros(RIS.N, 1); 
        for iter_epoch = 1:max_iters 

            H_BF = G' * diag(1 - 2*RIS_state_BF) * F; 
            % BS Digital Beamforming 
            [~, P_allocate_BF] = DigitalBeamforming(H_BF, P_static + P_RIS*sum(RIS_state_BF), P_BS_range(k), SE_min, sigma_noise); 
            % RIS Analog Beamforming 
            update_state_BF = RISBeamforming_BF(F, G, P_allocate_BF, P_RIS, P_BS_range(k), RIS_state_BF); 
            % recycle condition 
            if (sum(abs(update_state_BF - RIS_state_BF)) < iter_threshold) 
                break; 
            end 
            RIS_state_BF = update_state_BF; 

        end
        H_BF = G' * diag(1 - 2*RIS_state_BF) * F; 
        [W_BS_BF, P_allocate_BF] = DigitalBeamforming(H_BF, P_static + P_RIS*sum(RIS_state_BF), P_BS_range(k), SE_min, sigma_noise); 

        % EE Optimization (Exist Method)
        RIS_state_exist = zeros(RIS.N, 1); 
        for iter_epoch = 1:max_iters 

            H_exist = G' * diag(1 - 2*RIS_state_exist) * F; 
            [~, P_allocate_exist] = DigitalBeamforming(H_exist, P_static + P_RIS*sum(RIS_state_exist), P_BS_range(k), SE_min, sigma_noise); 
            update_state_exist = RISBeamforming_SubOpt(F, G, P_allocate_exist, P_RIS, P_BS_range(k), RIS_state_exist); 
            if (sum(abs(update_state_exist - RIS_state_BF)) < iter_threshold) 
                break; 
            end
            RIS_state_exist = update_state_exist; 

        end
        H_exist = G' * diag(1 - 2*RIS_state_exist) * F; 
        [W_BS_exist, P_allocate_exist] = DigitalBeamforming(H_exist, P_static + P_RIS*sum(RIS_state_exist), P_BS_range(k), SE_min, sigma_noise); 

        % EE Optimization (SDP Relaxation)
%         RIS_state_SDP = randi([0, 1], RIS.N, 1); 
        RIS_state_SDP = zeros(RIS.N, 1); 
        temp_count = 0; 
        for iter_epoch = 1:max_iters
            
            H_SDP = G' * diag(1 - 2*RIS_state_SDP) * F; 
            [~, P_allocate_SDP] = DigitalBeamforming(H_SDP, P_static + P_RIS*sum(RIS_state_SDP), P_BS_range(k), SE_min, sigma_noise); 
            update_state_SDP = RISBeamforming_SDP(F, G, P_allocate_SDP, P_RIS, P_BS_range(k), RIS_state_SDP); 
            if (sum(abs(update_state_SDP - RIS_state_SDP)) < iter_threshold) 
                temp_count = temp_count + 1; 
                if (temp_count >= 3) 
                    break; 
                end
            else 
                temp_count = 0;
            end
            RIS_state_SDP = update_state_SDP; 
            % fprintf('%d:%d:%d\n', k, epoch, iter_epoch); 

        end
        H_SDP = G' * diag(1 - 2*RIS_state_SDP) * F;
        [W_BS_SDP, P_allocate_SDP] = DigitalBeamforming(H_SDP, P_static + P_RIS*sum(RIS_state_SDP), P_BS_range(k), SE_min, sigma_noise); 

        % Random Analog Beamforming 
        RIS_state_rand = randi([0, 1], RIS.N, 1); 
        H_rand = G' * diag(1 - RIS_state_rand*2) * F; 
        [W_BS_rand, P_allocate_rand] = DigitalBeamforming(H_rand, P_static + P_RIS*sum(RIS_state_rand), P_BS_range(k), SE_min, sigma_noise); 

        % Closed RIS 
        RIS_state_close = zeros(RIS.N, 1); 
        H_close = G' * diag(1 - RIS_state_close*2) * F; 
        [W_BS_close, P_allocate_close] = DigitalBeamforming(H_close, P_static + P_RIS*sum(RIS_state_close), P_BS_range(k), SE_min, sigma_noise); 

        % Calculate the SE and EE 
        SE_BF(k) = SE_BF(k) + sum(log2(1 + P_allocate_BF/sigma_noise^2)); 
        EE_BF(k) = EE_BF(k) + BW * sum(log2(1 + P_allocate_BF/sigma_noise^2)) / (P_static + trace(W_BS_BF'*W_BS_BF) + P_RIS * sum(RIS_state_BF)); 
        SE_exist(k) = SE_exist(k) + sum(log2(1 + P_allocate_exist/sigma_noise^2)); 
        EE_exist(k) = EE_exist(k) + BW * sum(log2(1 + P_allocate_exist/sigma_noise^2)) / (P_static + trace(W_BS_exist'*W_BS_exist) + P_RIS * sum(RIS_state_exist)); 
        SE_SDP(k) = SE_SDP(k) + sum(log2(1 + P_allocate_SDP/sigma_noise^2)); 
        EE_SDP(k) = EE_SDP(k) + BW * sum(log2(1 + P_allocate_SDP/sigma_noise^2)) / (P_static + trace(W_BS_SDP'*W_BS_SDP) + P_RIS * sum(RIS_state_SDP)); 
        SE_rand(k) = SE_rand(k) + sum(log2(1 + P_allocate_rand/sigma_noise^2)); 
        EE_rand(k) = EE_rand(k) + BW * sum(log2(1 + P_allocate_rand/sigma_noise^2)) / (P_static + trace(W_BS_rand'*W_BS_rand) + P_RIS * sum(RIS_state_rand)); 
        SE_close_RIS(k) = SE_close_RIS(k) + sum(log2(1 + P_allocate_close/sigma_noise^2)); 
        EE_close_RIS(k) = EE_close_RIS(k) + BW * sum(log2(1 + P_allocate_close/sigma_noise^2)) / (P_static + trace(W_BS_close'*W_BS_close)); 

    end

    % fprintf('%d Over! RIS Open: %d, RIS(rand) Open: %d\n', k, sum(RIS_state_BF), sum(RIS_state_rand));
    % fprintf('%d/%d Over! Optimization: SE = %f, EE = %f  Compare Group: SE = %f, EE = %f  Random: SE = %f, EE = %f  Closed RIS: SE = %f, EE = %f\n', k, P_BS_number, SE_BF(k)/epochs, EE_BF(k)/epochs, SE_SDP(k)/epochs, EE_SDP(k)/epochs, SE_rand(k)/epochs, EE_rand(k)/epochs, SE_close_RIS(k)/epochs, EE_close_RIS(k)/epochs); 
    fprintf('|    %2d/%2d    | %6.2f | %8.0f | %6.2f | %8.0f | %6.2f | %8.0f | %6.2f | %8.0f | %6.2f | %8.0f |\n', k, P_BS_number, SE_SDP(k)/epochs, EE_SDP(k)/epochs, SE_BF(k)/epochs, EE_BF(k)/epochs, SE_exist(k)/epochs, EE_exist(k)/epochs, SE_rand(k)/epochs, EE_rand(k)/epochs, SE_close_RIS(k)/epochs, EE_close_RIS(k)/epochs); 
    
end

SE_BF = SE_BF / epochs;
EE_BF = EE_BF / epochs;
SE_exist = SE_exist / epochs; 
EE_exist = EE_exist / epochs; 
SE_SDP = SE_SDP / epochs;
EE_SDP = EE_SDP / epochs; 
SE_rand = SE_rand / epochs;
EE_rand = EE_rand / epochs;
SE_close_RIS = SE_close_RIS / epochs; 
EE_close_RIS = EE_close_RIS / epochs; 

figure(); hold on; box on; grid on;
plot(pow2db(P_BS_range), SE_SDP, 'Marker', 'x', 'Linewidth', 2, 'Color', '#FF0000'); 
plot(pow2db(P_BS_range), SE_BF, 'Marker', '*', 'Linewidth', 2, 'Color', '#0000FF'); 
plot(pow2db(P_BS_range), SE_exist, 'Marker', '^', 'Linewidth', 2, 'LineStyle', '--', 'Color', '#EDB120'); 
plot(pow2db(P_BS_range), SE_close_RIS, 'Marker', 'v', 'Linewidth', 2, 'LineStyle', '-', 'Color', '#77AC30'); 
plot(pow2db(P_BS_range), SE_rand, 'Marker', 'o', 'Linewidth', 2, 'LineStyle', '-', 'Color', '#000000'); 
legend('SDP Relaxation', 'Search with Gradient', 'Exist Method', 'All-OFF RIS', 'Random RIS'); 
xlabel('BS transmit power (dBW)');
ylabel('Spectrum Efficiency (bps/Hz)'); 
% saveas(gcf, 'figures/SE_64RIS_100_SDP.fig'); 

figure(); hold on; box on; grid on;
plot(pow2db(P_BS_range), EE_SDP, 'Marker', 'x', 'Linewidth', 2, 'Color', '#FF0000'); 
plot(pow2db(P_BS_range), EE_BF, 'Marker', '*', 'Linewidth', 2, 'Color', '#0000FF'); 
plot(pow2db(P_BS_range), EE_exist, 'Marker', '^', 'Linewidth', 2, 'LineStyle', '--', 'Color', '#EDB120'); 
plot(pow2db(P_BS_range), EE_close_RIS, 'Marker', 'v', 'Linewidth', 2, 'LineStyle', '-', 'Color', '#77AC30'); 
plot(pow2db(P_BS_range), EE_rand, 'Marker', 'o', 'Linewidth', 2, 'LineStyle', '-', 'Color', '#000000'); 
legend('SDP Relaxation', 'Search with Gradient', 'Exist Method', 'All-OFF RIS', 'Random RIS'); 
xlabel('BS transmit power (dBW)');
ylabel('Energy Efficiency (bits/Joule)'); 
% saveas(gcf, 'figures/EE_64RIS_100_SDP.fig'); 


% Utils
function [R, theta, psi] = randPos(R_range, theta_range, psi_range, Number)

    if (~exist('Number', 'var'))
        Number = 1;
    end

    R = R_range(1) + (R_range(2) - R_range(1)) * rand(Number, 1);
    theta = theta_range(1) + (theta_range(2) - theta_range(1)) * rand(Number, 1);
    psi = psi_range(1) + (psi_range(2) - psi_range(1)) * rand(Number, 1);

end
