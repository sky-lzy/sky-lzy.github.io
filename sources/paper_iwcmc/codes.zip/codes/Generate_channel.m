function [G, F] = Generate_channel(RIS, BS, US, lambda, kappa)

    G = Sub_channel(RIS.Ny, RIS.Nz, BS.M, BS.theta, BS.phi, BS.dis, lambda, kappa); 
    F = zeros(RIS.N, US.K); 
    for iter_k = 1:US.K
        F(:, iter_k) = Sub_channel(RIS.Ny, RIS.Nz, 1, US.theta(iter_k), US.phi(iter_k), US.dis(iter_k), lambda, kappa); 
    end

end

function F_sub = Sub_channel(Ny, Nz, M, theta, phi, dis, lambda, kappa)

    N = Ny * Nz;

    % channel gain
    z = lambda / (4*pi*dis) * exp(1j*2*pi*rand());

    % create the LOS channel
    alpha_M = exp(1j*pi*sin(theta)*sin(phi)*(0:M-1)).';
    alpha_Ny = exp(1j*pi*sin(-theta)*sin(-phi)*(0:Ny-1)).';
    alpha_Nz = exp(1j*pi*cos(phi*(0:Nz-1))).';
    alpha_N = kron(alpha_Ny, alpha_Nz);
    F_los = alpha_N*(alpha_M)';

    % create the NLOS channel
    F_nlos = (randn(N, M) + 1j*randn(N, M)) / sqrt(2);

    % create the channel
    F_sub = z * (sqrt(kappa/(1+kappa))*F_los + sqrt(1/(1+kappa))*F_nlos);

end