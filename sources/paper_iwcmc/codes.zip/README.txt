This simulation code package is mainly used to reproduce the results of the following paper [1]:

[1] Z. Li, J. Zhang, J. Zhu and L. Dai, “RIS energy efficiency optimization with practical power models”, IEEE International Wireless Communications and Mobile Computing Conference (IWCMC'23), Marrakesh, Morocco, Jun. 2023. 

*********************************************************************************************************************************
If you use this simulation code package in any way, please cite the original paper [1] above. 
 
The author in charge of this simulation code package is: Zhiyi Li (email: lizhiyi20@mails.tsinghua.edu.cn).

Reference: We highly respect reproducible research, so we try to provide the simulation codes for our published papers (more information can be found at: 
http://oa.ee.tsinghua.edu.cn/dailinglong/publications/publications.html). 

Please note that MATLAB R2022a and CVX 2.2 are used for this simulation code package, and there may be some incompatibility problems among different MATLAB/CVX versions. 

Copyright reserved by the Broadband Communications and Signal Processing Laboratory (led by Dr. Linglong Dai), Beijing National Research Center for Information Science and Technology (BNRist), Department of Electronic Engineering, Tsinghua University, Beijing 100084, China. 

*********************************************************************************************************************************
Abstract of the paper: 

Reconfigurable intelligent surface (RIS) has been envisioned as a promising research direction for future wireless communications. 
As an important indicator of RIS-assisted communication systems in green wireless communications, energy efficiency (EE) receives intensive research interest as an optimization target. 
Recently, an increasing number of works have been devoted to EE maximization in RIS-assisted systems, in which the power consumptions of the base station and RIS are jointly optimized. 
However, most existing works ignored the different power consumption between the ON and OFF states of the RIS elements, which mismatches the characteristics of the real-world physical components.  
To construct a more correct power dissipation model for EE optimization in RIS-aided systems, in this paper, we establish a novel ON-OFF aware power dissipation model for the RIS elements. 
Based on this new model, the EE optimization problem is re-formulated, and corresponding low-complexity algorithms are proposed by leveraging the mathematical structures of the problem. 
Simulation results verify the effectiveness of the proposed algorithms across a wide range of scenarios.  
*********************************************************************************************************************************
How to use this simulation code package?

All figures can be derived by running the .m files.

The simulation results in Fig. 1 and Fig. 2 (SE and EE with different BS transmit power) can be directly obtained by running sim_SDP.m. 
The simulation results in Fig. 3 and Fig. 4 (SE and EE with different numbers of RIS elements) can be directly obtained by running sim_RIS.m. 

Note that running code costs much time, thus you can simply reduce the number of iterations by setting "epochs" less in .m files, which may reduce the smoothness of the curves at the same time. 
*********************************************************************************************************************************
Enjoy the reproducible research!
